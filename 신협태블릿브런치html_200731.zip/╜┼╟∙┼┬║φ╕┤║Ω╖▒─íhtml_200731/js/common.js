
$(document).ready(function(){
    // if(sessnUser.MOBIL_KMACH.indexOf("SM-T860")==-1 && sessnUser.MOBIL_KMACH.indexOf("SM-T865")==-1) {
    //     $("#sitemap.overlay, .btn-sitemap span, #gnb nav > ul > li > a + div, #wrap.main > #container > #content").css("transition", "none"); //에니메이션 삭제 200615 (가장 첫줄에)  
    // }
    // sitemap 200416
    var posY;
    $(".btn-sitemap").click(function(){
        $(this).toggleClass("on");
        $("#sitemap.overlay").toggleClass("on");
        if ($(this).hasClass('on')){
            nativeUtil.callNativeRtn("setSttBarColor", {"color":"white"});
            posY = $(window).scrollTop();
            $("html, body").addClass("not-scroll");
            $("#container").css("top",-posY);
            $(".step").css("top", "74px"); // 200521 수정
        } else {
            nativeUtil.callNativeRtn("setSttBarColor", {"color":"black"});
            $("html, body").removeClass("not-scroll");
            posY = $(window).scrollTop(posY);
        }
    });
    // sitemap 200305
    $("#sitemap nav > ul > li").click(function(){
        $(this).addClass("on");
        $(this).siblings("li").removeClass("on");
    });
    $("#sitemap nav > ul > li > a + div li a").click(function(){
        if ($(this).parent("li").hasClass('on')){
            $("#sitemap nav > ul > li > a + div li").removeClass("on");
        } else {
            $(this).parent("li").addClass("on");
            $("#sitemap nav > ul > li > a + div li").not($(this).parent("li")).removeClass("on");
        }
    });
    $("#header h2 a").click(function(){
        $(this).toggleClass("on");
    });

    // gnb open
    $("#gnb > nav > ul > li").click(function(){
        $(this).addClass("on");
        $(this).siblings("li").removeClass("on");
        $("body").addClass("open-menu");
    });
    $("#gnb nav > ul > li > a + div li a").click(function(){
        $(this).parents("li").addClass("on");
        $(this).parents().siblings("li").removeClass("on");
    });
    // gnb close
    $(".menu-overlay, #header, .btn-sitemap").click(function(){ /* 200305 수정 */
        $("#gnb > nav > ul > li").removeClass("on");
        $("body").removeClass("open-menu");
    });

    // 스케줄 리스트 버튼
    $(document).mouseup(function (e) {
        if ($(e.target).parents(".schedule-list > ul > li").length == 0) {
            $(".schedule-list > ul > li").removeClass("on");
            $(".schedule-list > ul > li > div.btn-box").hide();
        }
    });
    $(".schedule-list > ul > li > a").click(function () {
        var li = $(this).parent();
        var ul = li.parent()
        ul.find("li").removeClass("on");
        ul.find("div.btn-box").not(li.find("div.btn-box")).hide();
        li.children("div.btn-box").toggle();/* fadeIn slideToggle toggle */
        if (li.children("div.btn-box").is(":visible")) {
            li.addClass("on");
        }
    });

    // accordion List
    $(function(){
        Accordionlist();
        AccordionMemo();
    });    
    function Accordionlist(){
        $('.accordion > li > div > button').off('click');
        $('.accordion > li > div > button').on('click' , function(){
            var title = $(this).parents('li');
            if (title.hasClass('on')){
                $(".accordion > li").removeClass("on");
            } else {
                title.addClass("on");
                $(".accordion > li").not(title).removeClass("on");
            }
        });
    }

    function AccordionMemo(){
        $('.mmtit').off('click');
        $('.mmtit').on('click' , function(){
            var memo = $(this);
            if (memo.hasClass('on')){
                $(".mmtit").removeClass("on");
            } else {
                memo.addClass("on");
                $(".mmtit").not(memo).removeClass("on");
            }
        });
    }

    // 화면확대, 화면 회전
    $(".btn-ctrl").click(function () {
        $(this).parent().addClass("open");
    });
    $(".btn-setup-area > ul .close").click(function () {
        $(this).parent().parent().removeClass("open");
    });
    $(".btn-setup-area .expand").click(function () {
        $(this).toggleClass("on");
        $("html").toggleClass("zoom");
    });
    if(commonUtil.isMobile()){
        //화면전환 초기화
        $(".btn-setup-area .rotate").click(function () {
            var rtn = nativeUtil.callNativeRtn("reverseOrientation", "");
        });
    }
});




